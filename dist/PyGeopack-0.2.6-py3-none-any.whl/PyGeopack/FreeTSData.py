import numpy as np
from ._CFunctions import _CFreeTSData

###### File created automatically using PopulateCtypes ######

def FreeTSData():

	#Convert input variables to appropriate numpy dtype:
	_CFreeTSData()

