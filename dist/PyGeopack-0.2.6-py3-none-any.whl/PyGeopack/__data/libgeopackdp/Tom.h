#ifndef __TOM_H__
#define __TOM_H__
#include <stdio.h>
#include <stdlib.h>
#include "libgeopack.h"


#endif
void tom_(double *x, double *y, double *z, int *n, int *Date, float *ut, double *Bx, double *By, double *Bz);
void _Tom96C(double *x, double *y, double *z, int n, int Date, float ut, double *Bx, double *By, double *Bz);
