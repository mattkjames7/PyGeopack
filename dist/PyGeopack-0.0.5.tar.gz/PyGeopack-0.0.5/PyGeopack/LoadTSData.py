import numpy as np
from ._CFunctions import _CLoadTSData

###### File created automatically using PopulateCtypes ######

def LoadTSData():

	#Convert input variables to appropriate numpy dtype:
	_CLoadTSData()

