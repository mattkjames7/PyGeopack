from .FreeTSData import FreeTSData
def __del__():
	print('Goodbye!')
	FreeTSData()
