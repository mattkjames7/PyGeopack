#ifndef __TOM_H__
#define __TOM_H__
#include <stdio.h>
#include <stdlib.h>
#include "libgeopack.h"


#endif
void tom_(float *x, float *y, float *z, int *n, int *Date, float *ut, float *Bx, float *By, float *Bz);
void _Tom96C(float *x, float *y, float *z, int n, int Date, float ut, float *Bx, float *By, float *Bz);
