import os
import numpy as np

def _CheckFirstImport():
	#first of all - check if the shared object exists
	SOFile = os.path.dirname(__file__)+"/__data/libgeopack/libgeopack.so"
	if not os.path.isfile(SOFile):
		print("libgeopack.so not found - attempting compilation!")
		CWD = os.getcwd()
		os.chdir(os.path.dirname(__file__)+"/__data/libgeopack/")
		os.system('make')
		os.chdir(CWD)
		
	DataFile = os.path.dirname(__file__)+"/__data/libgeopack/data/TSdata.bin"
	if not os.path.isfile(DataFile):
		print("data file has not been extracted yet - extracting!")
		CWD = os.getcwd()
		os.chdir(os.path.dirname(__file__)+"/__data/libgeopack/data")
		os.system('7z x -y TSdata.bin.tar.7z')
		os.system('tar -xf TSdata.bin.tar')
		os.chdir(CWD)		
